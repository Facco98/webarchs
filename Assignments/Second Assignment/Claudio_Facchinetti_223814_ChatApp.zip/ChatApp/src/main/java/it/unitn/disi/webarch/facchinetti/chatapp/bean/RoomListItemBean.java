package it.unitn.disi.webarch.facchinetti.chatapp.bean;

public class RoomListItemBean {

    private String name;
    private String url;

    public RoomListItemBean(){

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
