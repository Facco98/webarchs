package it.unitn.disi.webarch.facchinetti.chatapp.bean;

import java.util.ArrayList;

public class MessageListBean extends ArrayList<MessageBean> {



}
